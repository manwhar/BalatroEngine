return {
  mode = "shop_classifier",
  calibration_mode = "setup",
  max_frames = 20000,
  frames_per_phase = 100,
  perkeo_max_consumables = 5,
  show_shop_prices = false,
  card_selection_chance = "50%",
  rois = {
    card_hand = {x=508.319934, y=567.839093, w=1071.056521, h=322.734447},
    voucher = {x=656.059547, y=714.459732, w=360.743773, h=284.420985},
    consumeables = {x=1369.783812, y=30.836806, w=425.206356, h=270.406328},
    booster = {x=1071.358597, y=724.761198, w=427.707911, h=300.000000},
    joker_bar = {x=512.701385, y=20.409878, w=868.473724, h=259.967609},
    shop = {x=818.386186, y=369.181989, w=720.772049, h=280.979925},
    pack = {x=565.612571, y=588.005101, w=960.654887, h=307.239491},
  },
  boxes = {
    item_card = {w=0.524853, h=1.052198, ox=-0.230837, oy=-0.024396},
    booster_card = {w=1.000000, h=1.000000, ox=0.000000, oy=0.000000},
    voucher_card = {w=0.524853, h=1.052198, ox=-0.230837, oy=-0.024396},
    card = {w=0.465890, h=1.040970, ox=-0.240265, oy=0.020829},
    joker_bar_card = {w=0.524853, h=1.052198, ox=-0.230837, oy=-0.024396},
    consumeable_card = {w=0.524853, h=1.052198, ox=-0.230837, oy=-0.024396},
  }
}
